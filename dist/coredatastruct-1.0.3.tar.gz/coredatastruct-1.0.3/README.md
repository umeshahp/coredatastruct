coredatastruct
======

Core data structures to ease operation like BST, Linked List, Tree, Btree etc



------------
Installation
------------

For a manual installation 
------------
```

   mkdir coredatastruct
   wget https://github.com/umeshahp/coredatastruct.git
   cd coredatastruct
   python setup.py install
   
 
```



##Usage:


```
To be filled
```

```
na
```


```

```